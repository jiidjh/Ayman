# Predictive Healthcare Analytics

## Overview
A Flask web application that predicts hospital readmissions using machine learning models.

## Setup
1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Run the app:
   ```
   python app.py
   ```
3. Open `http://127.0.0.1:5000` in your browser.

## File Structure
- app.py: Flask application.
- models/: Pre-trained models.
- utils/: Preprocessing scripts.
- templates/: HTML files.
- requirements.txt: Project dependencies.