import numpy as np
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

def preprocess_input(age, gender, diagnosis, severity, length_of_stay):
    gender_encoded = 1 if gender == 'M' else 0
    diagnosis_map = {'Diabetes': 0, 'Heart Disease': 1, 'Cancer': 2}
    severity_map = {'low': 0, 'medium': 1, 'high': 2}

    diagnosis_encoded = diagnosis_map.get(diagnosis, 0)
    severity_encoded = severity_map.get(severity, 0)

    input_array = np.array([[age, gender_encoded, diagnosis_encoded, severity_encoded, length_of_stay]])
    input_array = scaler.fit_transform(input_array)
    return input_array