from flask import Flask, request, render_template
import pickle
import numpy as np
from tensorflow.keras.models import load_model
from utils.preprocess import preprocess_input

app = Flask(__name__)

# Load Models
logistic_model = pickle.load(open('models/logistic_regression.pkl', 'rb'))
random_forest_model = pickle.load(open('models/random_forest.pkl', 'rb'))
neural_network_model = load_model('models/neural_network.h5')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        age = request.form['age']
        gender = request.form['gender']
        diagnosis = request.form['diagnosis']
        severity = request.form['severity']
        length_of_stay = request.form['length_of_stay']
        model_type = request.form['model_type']
        
        # Preprocess input
        input_data = preprocess_input(age, gender, diagnosis, severity, length_of_stay)
        
        # Make prediction
        if model_type == 'Logistic Regression':
            prediction = logistic_model.predict(input_data)
        elif model_type == 'Random Forest':
            prediction = random_forest_model.predict(input_data)
        elif model_type == 'Neural Network':
            prediction = neural_network_model.predict(input_data)
        else:
            prediction = 'Invalid model selection'

        return render_template('index.html', prediction=prediction)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)